#pragma once

#include <lua.h>

LUALIB_API int luaopen_lsqlite3(lua_State* L);
