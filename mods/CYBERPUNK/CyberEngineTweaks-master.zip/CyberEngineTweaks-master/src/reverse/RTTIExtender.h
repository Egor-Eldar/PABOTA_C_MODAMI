#pragma once
#include <RED4ext/CName.hpp>

class RTTIExtender
{
    static void AddFunctionalTests();
    static void AddEntitySpawner();

public:
    static void Initialize();
};