#pragma once

namespace RED4ext
{
struct CClass;
struct IRTTIType;
struct CProperty;
} // namespace RED4ext

namespace GameDump
{
struct DumpVTablesTask
{
    static void Run();
};
} // namespace GameDump
